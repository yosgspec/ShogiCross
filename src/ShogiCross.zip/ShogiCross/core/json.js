import {canvasFont, gameSoft, games, boards, panels, pieces, pieceRange, pieceCost} from "./json/xhr.js";
export {canvasFont, gameSoft, games, boards, panels, pieces, pieceRange, pieceCost};
