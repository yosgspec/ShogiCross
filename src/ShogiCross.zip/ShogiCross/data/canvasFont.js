export default {
	"fonts": [
		["Noto Serif JP", 900],
		["Noto Emoji", 400],
		["Noto Sans Symbols 2", 400],
		["Noto Sans Symbols", 400],
		["Noto Serif", 900],
		["Noto Serif TC", 900]
	]
}
